# pygame-jam-summer-2022

This game was done for the 2022 pygame summer jam.

The music used is the following:
https://www.youtube.com/watch?v=HlA2dMNNdtw

The font used is named Squarefont
https://www.dafont.com/squarefont.font

The color palette is the following:
https://lospec.com/palette-list/slso8

Big big thanks to Simon little feets for the help!

Thanks for playing!