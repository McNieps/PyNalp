from typing import Literal


ValidMouseAction = Literal["hover", "pressed", "released"]
