from src.engine.shaders.black_hole import BlackHoleShader
from src.engine.shaders.chromatic_aberration import ChromaticAberrationShader
from src.engine.shaders.blur import BlurShader
from src.engine.shaders.grayscale import GrayscaleShader



