from src.engine.scene.sprites.classic_sprite import Sprite
from src.engine.scene.sprites.shader_sprite import ShaderSprite
from src.engine.scene.sprites.advanced_sprite import AdvancedSprite
