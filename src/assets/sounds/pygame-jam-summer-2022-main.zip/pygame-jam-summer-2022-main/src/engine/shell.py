class Shell:
    def __init__(self):
        print("Hello, I am a shell!")
