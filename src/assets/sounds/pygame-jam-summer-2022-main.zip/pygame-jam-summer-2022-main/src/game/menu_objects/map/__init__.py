from src.game.menu_objects.map.galaxy import Galaxy
from src.game.menu_objects.map.sector import Sector
from src.game.menu_objects.map.star import Star
