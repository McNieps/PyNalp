from src.game.menu_objects.buttons.about_button import about_button_dict
from src.game.menu_objects.buttons.options_button import options_button_dict
from src.game.menu_objects.buttons.play_button import play_button_dict
from src.game.menu_objects.buttons.quit_button import quit_button_dict
from src.game.menu_objects.buttons.return_button import return_button_dict
from src.game.menu_objects.buttons.utils import highlight_sprite, create_button


