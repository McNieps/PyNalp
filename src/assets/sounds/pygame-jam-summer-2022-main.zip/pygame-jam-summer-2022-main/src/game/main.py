"""
Hello dear pygamer.
"""


from src.game.states.menu import menu

import pygame


def main():
    menu()


if __name__ == '__main__':
    main()
    pygame.quit()
